<?php
// config/database.php
$db_host = 'localhost';
$db_name = 'php_login_db';  // Your database name
$db_user = 'root';          // Default username
$db_pass = '';              // Default password (empty for XAMPP/WAMP)

try {
    $db = new PDO(
        "mysql:host=$db_host;dbname=$db_name", 
        $db_user, 
        $db_pass
    );
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>