<?php
// Database setup
$db = new PDO('mysql:host=localhost;dbname=php_login_db', 'root', '');
session_start();
?>