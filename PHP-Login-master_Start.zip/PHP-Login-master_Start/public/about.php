// About.php
<?php 
require_once '../template/header.php';
require_once '../config/config.php'; // Include config
?>

<body>
    <div class="container">
        <div class="header">
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contacts.php">Contact</a></li>
                </ul>
            </nav>
            <h3>About Us</h3>
        </div>

        <div class="main-content">
            <h1>Welcome <?php echo $_SESSION['Username'] ?? 'Guest'; ?></h1>
            
            <?php if(isset($_SESSION['Username'])): ?>
                <form action="logout.php" method="post">
                    <button type="submit">Log out</button>
                </form>
            <?php endif; ?>

            <div class="about-content">
                <h2>Our Story</h2>
                <p>Simple about page content here...</p>
            </div>
        </div>
    </div>

<?php require_once '../template/footer.php'; ?>