//register.php
<?php
require_once __DIR__.'/../config/config.php';
session_start();

// Redirect if already logged in
if(isset($_SESSION['Active'])) {
    header("Location: index.php");
    exit;
}

$error = '';

if(isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Simple validation
    if(empty($username) || empty($password)) {
        $error = 'Username and password are required';
    } 
    elseif($password !== $confirm_password) {
        $error = 'Passwords do not match';
    }
    elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    }
    else {
        try {
            // Check if username exists
            $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            
            if($stmt->rowCount() > 0) {
                $error = 'Username already taken';
            } else {
                // Insert new user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
                $stmt->execute([$username, $hashed_password]);
                
                $_SESSION['registration_success'] = true;
                header("Location: login.php");
                exit;
            }
        } catch(PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Register</title>
    <link rel="stylesheet" href="../css/signin.css">
</head>
<body>
<div class="container">
    <h2>Create Account</h2>
    
    <?php if($error): ?>
        <div class="alert"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <form method="post" class="form-signin">
        <label for="username">Username</label>
        <input type="text" name="username" id="username" required>
        
        <label for="password">Password (6+ characters)</label>
        <input type="password" name="password" id="password" required>
        
        <label for="confirm_password">Confirm Password</label>
        <input type="password" name="confirm_password" id="confirm_password" required>
        
        <button type="submit" name="register">Register</button>
    </form>
    
    <p>Already have an account? <a href="login.php">Login here</a></p>
</div>
</body>
</html>