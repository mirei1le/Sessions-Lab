//login.php
<?php
require_once '../config/config.php'; // This should point to your config file
session_start();

$error = ''; // Initialise error variable

if(isset($_POST['Submit'])) {
    // Get form inputs
    $input_username = $_POST['Username'] ?? '';
    $input_password = $_POST['Password'] ?? '';
    
    // Check against hardcoded admin first
    if($input_username === $admin_user && $input_password === $admin_pass) {
        $_SESSION['Username'] = $admin_user;
        $_SESSION['Active'] = true;
        header("Location: index.php");
        exit;
    }
    
    // If not admin, check database
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $input_username);
        $stmt->execute();
        
        if($user = $stmt->fetch()) {
            if(password_verify($input_password, $user['password'])) {
                $_SESSION['Username'] = $user['username'];
                $_SESSION['Active'] = true;
                header("Location: index.php");
                exit;
            }
        }
        
        // If we get here, credentials were invalid
        $error = 'Incorrect Username or Password';
        
    } catch(PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sign in</title>
    <link rel="stylesheet" href="../css/signin.css">
</head>
<body>
<div class="container">
    <?php if($error): ?>
        <div class="alert"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <form action="" method="post" name="Login_Form" class="form-signin">
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="inputUsername">Username</label>
        <input name="Username" type="text" id="inputUsername" class="form-control" placeholder="Username" required autofocus>
        <label for="inputPassword">Password</label>
        <input name="Password" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
        <button name="Submit" value="Login" class="button" type="submit">Sign in</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a></p>
</div>
</body>
</html>